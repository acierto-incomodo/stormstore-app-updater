const fs = require('fs');
const path = require('path');

function walkModules(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const files = [];

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);

    if (entry.isDirectory()) {
      files.push(...walkModules(fullPath));
    } else if (entry.isFile() && entry.name.endsWith('.module.sgs')) {
      files.push(fullPath);
    }
  }

  return files;
}

function loadRegistry(baseDir = path.join(__dirname, 'elements')) {
  const files = walkModules(baseDir).sort();
  const registry = {};

  for (const file of files) {
    const content = fs.readFileSync(file, 'utf8');
    const moduleData = JSON.parse(content);
    registry[moduleData.name] = {
      ...moduleData,
      file: path.relative(__dirname, file).replace(/\\/g, '/')
    };
  }

  return registry;
}

function resolveTemplate(template, values) {
  return template.replace(/\{\{(.*?)\}\}/g, (_, key) => {
    const trimmed = key.trim();
    return values[trimmed] !== undefined ? String(values[trimmed]) : '';
  });
}

function renderToHtml(name, options = {}) {
  const registry = loadRegistry();
  const definition = registry[name];

  if (!definition) {
    throw new Error(`No se encontró el módulo SGS: ${name}`);
  }

  const merged = { ...(definition.defaults || {}), ...(options || {}) };
  return resolveTemplate(definition.template, merged);
}

function renderSgsComponent(name, options = {}, target = null) {
  if (typeof document === 'undefined') {
    return renderToHtml(name, options);
  }

  const html = renderToHtml(name, options);
  const wrapper = document.createElement('div');
  wrapper.innerHTML = html;
  const node = wrapper.firstElementChild;

  if (target) {
    target.appendChild(node);
  }

  return node;
}

module.exports = {
  loadRegistry,
  renderToHtml,
  renderSgsComponent,
  registry: loadRegistry()
};
