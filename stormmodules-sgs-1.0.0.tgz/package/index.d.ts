export interface SgsModuleDefinition {
  name: string;
  description?: string;
  template: string;
  styles?: string;
  defaults?: Record<string, unknown>;
  file?: string;
}

export interface SgsModuleRegistry {
  [key: string]: SgsModuleDefinition;
}

export function loadRegistry(baseDir?: string): SgsModuleRegistry;
export function renderToHtml(name: string, options?: Record<string, unknown>): string;
export function renderSgsComponent(name: string, options?: Record<string, unknown>, target?: HTMLElement | null): HTMLElement | string;

export const registry: SgsModuleRegistry;
