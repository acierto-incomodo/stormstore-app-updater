#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');
const elementsDir = path.join(rootDir, 'elements');
const outputFile = path.join(__dirname, 'sgs-bundle.js');

function walk(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...walk(fullPath));
    } else if (entry.isFile() && entry.name.endsWith('.module.sgs')) {
      files.push(fullPath);
    }
  }
  return files;
}

const files = walk(elementsDir).sort();
const modules = [];

for (const file of files) {
  const content = fs.readFileSync(file, 'utf8');
  const moduleData = JSON.parse(content);
  const relPath = path.relative(rootDir, file).replace(/\\/g, '/');
  modules.push(`  ${JSON.stringify(moduleData.name)}: ${JSON.stringify({
    ...moduleData,
    file: relPath
  })}`);
}

const bundle = `(() => {
  const registry = {
${modules.join(',\n')}
  };

  function applyTemplate(template, values) {
    return template.replace(/\\{\\{(.*?)\\}\\}/g, (_, key) => {
      const trimmed = key.trim();
      return values[trimmed] !== undefined ? String(values[trimmed]) : '';
    });
  }

  function injectStyles(styles) {
    if (!styles) return;
    const existing = document.getElementById('storm-sgs-styles');
    if (existing) {
      existing.textContent += styles;
      return;
    }
    const style = document.createElement('style');
    style.id = 'storm-sgs-styles';
    style.textContent = styles;
    document.head.appendChild(style);
  }

  function renderSgsComponent(name, options = {}, target = document.body) {
    const definition = registry[name];
    if (!definition) {
      throw new Error('No se encontró el módulo SGS: ' + name);
    }

    const merged = { ...(definition.defaults || {}), ...(options || {}) };
    injectStyles(definition.styles || '');
    const html = applyTemplate(definition.template, merged);
    const wrapper = document.createElement('div');
    wrapper.innerHTML = html;
    const node = wrapper.firstElementChild;
    if (!node) {
      throw new Error('El template del módulo no produjo un nodo válido');
    }
    if (target) {
      target.appendChild(node);
    }
    return node;
  }

  window.SGSRegistry = registry;
  window.renderSgsComponent = renderSgsComponent;
})();
`;

fs.writeFileSync(outputFile, bundle, 'utf8');
console.log(`Bundle generado: ${path.relative(rootDir, outputFile)}`);
