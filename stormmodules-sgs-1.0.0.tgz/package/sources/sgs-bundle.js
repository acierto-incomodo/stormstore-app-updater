(() => {
  const registry = {
  "button": {"name":"button","description":"Botón prefab reutilizable para interfaces de Electron.","template":"<button id=\"{{id}}\" class=\"storm-btn storm-btn-{{variant}}\">{{label}}</button>","styles":".storm-btn{display:inline-block;padding:12px 16px;border:none;border-radius:8px;font:inherit;cursor:pointer;transition:transform .15s ease, box-shadow .15s ease;}.storm-btn:hover{transform:translateY(-1px);box-shadow:0 6px 18px rgba(0,0,0,.16);}.storm-btn-primary{background:#2563eb;color:white;}.storm-btn-secondary{background:#e2e8f0;color:#0f172a;}","defaults":{"id":"storm-button","variant":"primary","label":"Click me"},"file":"elements/buttons/button.module.sgs"},
  "card": {"name":"card","description":"Tarjeta reutilizable para mostrar contenido breve.","template":"<section id=\"{{id}}\" class=\"storm-card\"><h3 class=\"storm-card__title\">{{title}}</h3><p class=\"storm-card__content\">{{content}}</p></section>","styles":".storm-card{padding:16px;border:1px solid #e5e7eb;border-radius:12px;background:white;box-shadow:0 4px 12px rgba(0,0,0,.06);max-width:360px;}.storm-card__title{margin:0 0 8px;font-size:1rem;color:#111827;}.storm-card__content{margin:0;color:#4b5563;}","defaults":{"id":"storm-card","title":"Tarjeta","content":"Contenido generado desde un módulo .module.sgs"},"file":"elements/cards/card.module.sgs"},
  "title": {"name":"title","description":"Encabezado reusable para secciones o pantallas.","template":"<h2 id=\"{{id}}\" class=\"storm-title\">{{text}}</h2>","styles":".storm-title{margin:0 0 8px 0;font-size:1.4rem;font-weight:700;color:#111827;}","defaults":{"id":"storm-title","text":"Título de ejemplo"},"file":"elements/texts/title.module.sgs"}
  };

  function applyTemplate(template, values) {
    return template.replace(/\{\{(.*?)\}\}/g, (_, key) => {
      const trimmed = key.trim();
      return values[trimmed] !== undefined ? String(values[trimmed]) : '';
    });
  }

  function injectStyles(styles) {
    if (!styles) return;
    const existing = document.getElementById('storm-sgs-styles');
    if (existing) {
      existing.textContent += styles;
      return;
    }
    const style = document.createElement('style');
    style.id = 'storm-sgs-styles';
    style.textContent = styles;
    document.head.appendChild(style);
  }

  function renderSgsComponent(name, options = {}, target = document.body) {
    const definition = registry[name];
    if (!definition) {
      throw new Error('No se encontró el módulo SGS: ' + name);
    }

    const merged = { ...(definition.defaults || {}), ...(options || {}) };
    injectStyles(definition.styles || '');
    const html = applyTemplate(definition.template, merged);
    const wrapper = document.createElement('div');
    wrapper.innerHTML = html;
    const node = wrapper.firstElementChild;
    if (!node) {
      throw new Error('El template del módulo no produjo un nodo válido');
    }
    if (target) {
      target.appendChild(node);
    }
    return node;
  }

  window.SGSRegistry = registry;
  window.renderSgsComponent = renderSgsComponent;
})();
