# StormModules

StormModules es una propuesta simple para crear componentes reutilizables tipo prefabs usando archivos con extensión .module.sgs.

## Qué incluye

- Archivos de definición de componente en formato JSON con:
  - name
  - template
  - styles
  - defaults
- Un generador de bundle con Node.js que convierte todos los módulos en un archivo JavaScript listo para usar desde HTML.
- Un ejemplo de uso desde Electron o desde un navegador simple.

## Estructura

- elements/buttons/button.module.sgs
- elements/texts/title.module.sgs
- elements/cards/card.module.sgs
- sources/build-sgs-bundle.js
- example.html

## Cómo usarlo

1. Crea un archivo .module.sgs en alguna carpeta de elements.
2. Define su template, estilos y valores por defecto.
3. Ejecuta el generador:

```bash
node sources/build-sgs-bundle.js
```

4. Incluye el bundle en tu HTML:

```html
<script src="./sources/sgs-bundle.js"></script>
```

5. Renderiza un componente desde JavaScript:

```html
<div id="app"></div>
<script>
  window.renderSgsComponent('button', { id: 'save-btn', label: 'Guardar', variant: 'primary' }, document.getElementById('app'));
</script>
```

## Idea para Electron

En Electron puedes cargar este HTML en una ventana y usar los componentes como si fueran prefabs visuales. Solo necesitas:

```js
const { app, BrowserWindow } = require('electron');

function createWindow() {
  const win = new BrowserWindow({ width: 1000, height: 700 });
  win.loadFile('example.html');
}

app.whenReady().then(createWindow);
```

## Sugerencia de evolución

Puedes ampliar esto para que soporte:
- eventos como click
- slots para contenido interno
- temas
- componentes más complejos como inputs, modales y tablas
- integración con React, Vue o Web Components si luego deseas escalarlo
